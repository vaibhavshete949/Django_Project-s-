from django.shortcuts import render
from django.core.mail import send_mail
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from .models import Post
from .serializers import PostSerializer
from django.conf import settings
from rest_framework import status
from rest_framework.response import Response
from .pagination import PaginationsData

# Create your views here.

class PostListCreateAPIView(generics.ListCreateAPIView):
    pagination_class = PaginationsData
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return Post.objects.filter(author=user)

    def perform_create(self, serializer):
        post = serializer.save(author=self.request.user)
        subject = 'New Post Created'
        message = f'Your post "{post.title}" has been created successfully.'
        email_from = settings.EMAIL_HOST_USER
        email_to = 'your-email'
        send_mail(subject, message, email_from, [email_to])

        

class RetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def perform_update(self, serializer):
        serializer.save(author=self.request.user)
